package UIMS;

public class Address {
    public static String host = "10.60.65.8";
    public static String hostAddress = "http://" + host;

    public static String cjcxHost = "cjcx.jlu.edu.cn";
    public static String cjcxHostAddress = "http://" + cjcxHost;

    public static String socketHost = "119.23.108.28";
    public static String socketAddress = "http://" + socketHost;

}
